(function(){
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var root = document.documentElement;
  // header shadow + scroll progress
  var bar = document.getElementById('progress'), header = document.querySelector('header.site');
  function onScroll(){
    var y = window.scrollY || 0, h = document.documentElement.scrollHeight - innerHeight;
    if (bar) bar.style.transform = 'scaleX(' + (h > 0 ? Math.min(1, y / h) : 0) + ')';
    if (header) header.classList.toggle('scrolled', y > 40);
  }
  window.addEventListener('scroll', onScroll, {passive:true}); onScroll();
  if (reduce || !('IntersectionObserver' in window)) return;
  root.classList.add('anim');
  // scroll reveal with stagger
  var sel = '.sec-head,.card,.plain,.step,.fact,.market,.faq details,.table-box,.methods span,.prose > h2,.band-grid > *';
  var items = document.querySelectorAll('main ' + sel.split(',').join(',main '));
  items.forEach(function(el){
    if (el.closest('.hero')) return;
    var sibs = Array.prototype.indexOf.call(el.parentNode.children, el);
    el.classList.add('rv'); el.style.setProperty('--d', Math.min(sibs, 8) * 70 + 'ms');
  });
  var io = new IntersectionObserver(function(es){
    es.forEach(function(en){ if (en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); } });
  }, {rootMargin:'0px 0px -8% 0px', threshold:0.08});
  document.querySelectorAll('.rv').forEach(function(el){ io.observe(el); });
  // count-up numbers
  function countUp(el){
    var m = el.textContent.match(/^(\d+)(.*)$/); if (!m) return;
    var end = +m[1], rest = m[2], t0 = null;
    function step(t){ if (!t0) t0 = t; var p = Math.min(1, (t - t0) / 1200), v = Math.round(end * (1 - Math.pow(1 - p, 3)));
      el.textContent = v + rest; if (p < 1) requestAnimationFrame(step); }
    requestAnimationFrame(step);
  }
  var cio = new IntersectionObserver(function(es){
    es.forEach(function(en){ if (en.isIntersecting){ countUp(en.target); cio.unobserve(en.target); } });
  }, {threshold:0.6});
  document.querySelectorAll('.specs b, .fact b').forEach(function(el){ cio.observe(el); });
})();
document.querySelectorAll('.gallery').forEach(function(g){var m=g.querySelector('.gmain img');g.querySelectorAll('.gthumb').forEach(function(b){b.addEventListener('click',function(){m.src=b.dataset.src;g.querySelectorAll('.gthumb').forEach(function(o){o.classList.toggle('on',o===b);});});});});
(function(){var r=document.querySelector('.tb-rot');if(!r)return;var li=r.querySelectorAll('li'),i=0;if(!li.length)return;li[0].classList.add('on');
setInterval(function(){var c=li[i];c.classList.remove('on');c.classList.add('out');i=(i+1)%li.length;var n=li[i];n.classList.remove('out');n.classList.add('on');setTimeout(function(){c.classList.remove('out');},600);},3500);})();
(function(){var g=document.querySelector('.tgrid');var f=document.querySelector('.tfilter');if(!g||!f)return;var st={deco:'',fit:'',q:''};
function run(){g.querySelectorAll('.tcard').forEach(function(c){c.hidden=!((!st.deco||c.dataset.deco===st.deco)&&(!st.fit||c.dataset.fit===st.fit)&&(!st.q||c.dataset.name.indexOf(st.q)>-1));});var tc=document.querySelector('.tcount');if(tc){var v=g.querySelectorAll('.tcard:not([hidden])').length;tc.textContent='Showing '+v+' of '+tc.dataset.total+' styles';}}
f.querySelectorAll('button').forEach(function(b){b.addEventListener('click',function(){st[b.dataset.f]=b.dataset.v;b.parentNode.querySelectorAll('button').forEach(function(o){o.classList.toggle('on',o===b);});run();});});
var i=document.getElementById('tsearch');if(i)i.addEventListener('input',function(){st.q=i.value.toLowerCase().trim();run();});})();

/* Medical Wear menu (added after Leather Wear on pages built before it existed) */
(function(){
  function run(){
    if (document.querySelector('a.fly-name[href="medical-wear-manufacturer.html"], a[href="medical-wear-manufacturer.html"] b')) return;
    var FLY="<li class=\"fly-cat\"><a class=\"fly-name\" href=\"medical-wear-manufacturer.html\">Medical Wear<i aria-hidden=\"true\">\u203a</i></a><div class=\"fly-panel\"><a class=\"fly-all\" href=\"medical-wear-manufacturer.html\">View all</a><div class=\"fly-grid\"><a href=\"custom-medical-scrubs.html\">Medical Scrubs</a><a href=\"custom-lab-coats.html\">Lab Coats</a><a href=\"custom-nurse-uniforms.html\">Nurse Uniforms</a><a href=\"custom-surgical-gowns.html\">Surgical Gowns</a><a href=\"custom-patient-gowns.html\">Patient Gowns</a><a href=\"custom-scrub-caps.html\">Scrub Caps</a></div></div></li>", MOB="<a href=\"medical-wear-manufacturer.html\"><b>Medical Wear</b></a><a class=\"msub\" href=\"custom-medical-scrubs.html\">Medical Scrubs</a><a class=\"msub\" href=\"custom-lab-coats.html\">Lab Coats</a><a class=\"msub\" href=\"custom-nurse-uniforms.html\">Nurse Uniforms</a><a class=\"msub\" href=\"custom-surgical-gowns.html\">Surgical Gowns</a><a class=\"msub\" href=\"custom-patient-gowns.html\">Patient Gowns</a><a class=\"msub\" href=\"custom-scrub-caps.html\">Scrub Caps</a>", FOOT="<li><a href=\"medical-wear-manufacturer.html\">Medical Wear</a></li>";
    var a=document.querySelector('a.fly-name[href="leather-wear-manufacturer.html"]');
    if(a){var li=a.closest('li'); if(li) li.insertAdjacentHTML('afterend',FLY);}
    var m=document.querySelectorAll('a.msub[href="custom-leather-accessories.html"]');
    m.forEach(function(x){x.insertAdjacentHTML('afterend',MOB);});
    document.querySelectorAll('li > a[href="leather-wear-manufacturer.html"]').forEach(function(x){
      if(!x.classList.contains('fly-name') && x.parentElement.tagName==='LI' && !x.parentElement.classList.contains('fly-cat')) x.parentElement.insertAdjacentHTML('afterend',FOOT);
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',run); else run();
})();
